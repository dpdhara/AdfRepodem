# TESTS

Unit test cases for `diabetes_mlops` MLOps source code.
