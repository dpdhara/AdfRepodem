# Data

## Data Source

1. Original Data Source - [microsoft/MLOpsPython](https://github.com/microsoft/MLOpsPython/blob/master/data/diabetes.csv)
2. Added category column and empty values

## Current Data

1. [data_raw.csv](./data_raw.csv) : raw data used for training
2. [data_batch_input.csv](./data_batch_input.csv) : sample data for batch scoring
