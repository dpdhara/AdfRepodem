# ML Source

## Overview

This contains machine learning code. That will be developed, unit tested, packaged and delivered independently and typically maintained by Data scientist in an organization.

## Contents

1. [src](src/) : machine learning source code, that will be packaged as Python `wheel`.
2. [tests](tests/) : unit test cases for `src`.
