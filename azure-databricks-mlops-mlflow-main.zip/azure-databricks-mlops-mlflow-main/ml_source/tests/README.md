# TESTS

Unit test cases for `diabetes` machine learning source code.
