# Diabetes Model

## Source

1. Original Source - [microsoft/MLOpsPython](https://github.com/microsoft/MLOpsPython)
2. Added feature engineering
