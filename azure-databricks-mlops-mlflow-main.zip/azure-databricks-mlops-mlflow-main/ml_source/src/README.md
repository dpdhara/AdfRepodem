# SRC

## Overview

Source code for machine learning, based on  -

1. [diabetes](diabetes/) contains machine learning source code.
2. `monitoring` contains logging class for logging into Application Insights.
3. The machine python functions will be called from MLOps python functions.
